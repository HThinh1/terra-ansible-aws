import boto3

sqs = boto3.resource('sqs',
                      aws_access_key_id='AKIA5FOQROIWUKBRBZ6G',
                      aws_secret_access_key='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')

queue = sqs.get_queue_by_name(QueueName='test')

for message in queue.receive_messages():
    import json
    print(message.body)
    mesJson =  json.loads(message.body)
    data = ''
    with open("terraform.tfvars", "r") as f:
        data = f.read()
        data = data.split('\n')
        for i in range(len(data)):
            if 'aws_access_key' in data[i]:
                data[i] = 'aws_access_key="' + mesJson['aws_access_key'] + '"'
            if 'aws_secret_key' in data[i]:
                data[i] = 'aws_secret_key="' + mesJson['aws_secret_key'] + '"'
    with open("terraform.tfvars", "w") as f:
        f.write('\n'.join(data))
    message.delete()
