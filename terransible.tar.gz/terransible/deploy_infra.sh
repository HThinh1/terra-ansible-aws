#!/bin/bash
sed -i '/aws_access_key/c\aws_access_key=""' terraform.tfvars
sed -i '/aws_secret_key/c\aws_secret_key=""' terraform.tfvars
rm terraform.tfstate*
python3 pullSQS.py
terraform apply -auto-approve
sed -i '/aws_access_key/c\aws_access_key=""' terraform.tfvars
sed -i '/aws_secret_key/c\aws_secret_key=""' terraform.tfvars
